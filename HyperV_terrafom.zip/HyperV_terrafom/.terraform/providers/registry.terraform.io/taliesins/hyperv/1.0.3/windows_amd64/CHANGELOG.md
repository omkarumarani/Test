## [1.0.3](https://github.com/taliesins/terraform-provider-hyperv/compare/v1.0.2...v1.0.3) (2021-03-20)


### Bug Fixes

* **static-or-dynamic:** don't default to static, but rather force people to chose static over dynamic. ([da10a53](https://github.com/taliesins/terraform-provider-hyperv/commit/da10a536792f8f3cecba6c988c011eff65866812))
* improve error message to make it obvious what to do when this error occurs ([da23bf6](https://github.com/taliesins/terraform-provider-hyperv/commit/da23bf6c7acde50fbe3bc14b2a7d5a4f0b96f3e1))



## [1.0.2](https://github.com/taliesins/terraform-provider-hyperv/compare/v1.0.1...v1.0.2) (2021-03-09)



## [1.0.1](https://github.com/taliesins/terraform-provider-hyperv/compare/v1.0.0...v1.0.1) (2020-09-23)



# 1.0.0 (2020-09-23)



