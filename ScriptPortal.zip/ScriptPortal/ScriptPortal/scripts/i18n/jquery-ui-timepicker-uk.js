/* Ukrainian translation for the jQuery Timepicker Addon */
/* Written by Sergey Noskov */
(function($) {
	$.timepicker.regional['uk'] = {
		timeOnlyTitle: 'Виберіть час',
		timeText: 'Час',
		hourText: 'Години',
		minuteText: 'Хвилини',
		secondText: 'Секунди',
		millisecText: 'Мілісекунди',
		microsecText: 'Мікросекунди',
		timezoneText: 'Часовий пояс',
		currentText: 'Зараз',
		closeText: 'Закрити',
		timeFormat: 'HH:mm',
		timeSuffix: '',
		amNames: ['AM', 'A'],
		pmNames: ['PM', 'P'],
		isRTL: false
	};
	$.timepicker.setDefaults($.timepicker.regional['uk']);
})(jQuery);
