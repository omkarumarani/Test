---
name: Support Question ❓
about: If you have a question, you can try asking in the scriptanalyzer channel of the international PowerShell Slack channel first.

---

* Slack Community Chat: https://powershell.slack.com (you can sign-up at http://slack.poshcode.org/ for an invite)
* Also have a look at the `RoleDocumentation` folder for more information on each rule:
https://github.com/PowerShell/PSScriptAnalyzer/tree/development/RuleDocumentation