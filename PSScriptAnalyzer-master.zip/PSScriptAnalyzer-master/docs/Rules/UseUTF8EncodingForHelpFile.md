---
description: Use UTF8 Encoding For Help File
ms.custom: PSSA v1.21.0
ms.date: 10/18/2021
ms.topic: reference
title: UseUTF8EncodingForHelpFile
---
# UseUTF8EncodingForHelpFile

**Severity Level: Warning**

## Description

Check if help file uses UTF-8 encoding.
