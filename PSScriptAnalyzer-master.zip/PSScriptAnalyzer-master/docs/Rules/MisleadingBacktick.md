---
description: Misleading Backtick
ms.custom: PSSA v1.21.0
ms.date: 10/18/2021
ms.topic: reference
title: MisleadingBacktick
---
# MisleadingBacktick

**Severity Level: Warning**

## Description

Checks that lines don't end with a backtick followed by whitespace.
