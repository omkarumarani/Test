﻿$correctPath = "www.bing.com"
$externalSite = "//outside.co/test"
rmdir /s /q ".\Directory"
function Test
{
	$filesNode = $infoXml.SelectSingleNode("//files")
}
$sd = "O:BAG:BAD:(A;;0x800;;;WD)(A;;0x120fff;;;SY)(A;;0x120fff;;;LS)(A;;0x120fff;;;NS)(A;;0x120fff;;;BA)(A;;0xee5;;;LU)(A;;LC;;;MU)(A;;0x800;;;AG)"
$msg = [System.String]::Format("1:{0}", "test")
 $internalId = $Id -replace '^([^/])','/$1' -as $Id.GetType()