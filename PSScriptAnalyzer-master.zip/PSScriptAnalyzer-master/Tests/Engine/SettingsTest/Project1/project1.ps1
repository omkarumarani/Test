gci
Write-Host "Do not use write-host"