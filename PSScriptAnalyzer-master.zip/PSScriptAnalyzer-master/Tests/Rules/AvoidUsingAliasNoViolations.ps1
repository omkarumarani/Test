﻿Write-Host "No alias for me plz!"
Clear-Host
Invoke-Expression "Clear-Host"
Clear-History