﻿$declaredVar = "Declared just for fun"
$declaredVar2 = "I don't want to use this var"