﻿
New-Alias -Name Name -Scope `
Global -Value Value
nal -Name Name -Value Value -Scope "Global"

New-Alias -Name Name -scope:global -Value Value
nal -Name Name -scope:global -Value Value
