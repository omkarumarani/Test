﻿iex "I want to use alias"
cls