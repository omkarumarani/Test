﻿
New-Alias -Name Name1 -Value Value
nal -Name Name2 -Value Value -Scope Script

New-Alias -Name Name3 -scope:Script -Value Value
nal -Name Name4 -scope:Script -Value Value
