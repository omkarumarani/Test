Function Get-Foo
{

}

Function Get-Bar
{

}

Export-ModuleMember -Function Get-Foo
Export-ModuleMember -Function Get-Bar
