Function Get-Foo
{

}

Function Get-Bar
{

}

Export-ModuleMember -Function Get-Foo -Alias gfoo
Export-ModuleMember -Function Get-Bar -Alias gbar